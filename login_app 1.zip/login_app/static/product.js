document.addEventListener('DOMContentLoaded', function() {
    const buyButtons = document.querySelectorAll('.buy-button');
    const barcodeContainer = document.getElementById('barcode-container');

    buyButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            barcodeContainer.style.display = 'block'; // Show the barcode
        });
    });
});
