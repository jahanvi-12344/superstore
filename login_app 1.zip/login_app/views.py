from django.shortcuts import render, redirect
import mysql.connector as sql
from django.db import connection
from django.contrib import messages
from django.shortcuts import render, get_object_or_404


name=''
email_signup=''
password_signup=''
#repeat=''
password_signin=''
email_signin=''
# Create your views here.
def signin(req):
    global email_signin,password_signin
    if req.method=='POST':
        m1=sql.connect(host='localhost',user='root',password='Jahanvi@123',database='superstore_data')
        cursor=m1.cursor()
        d1=req.POST
        for keys,values in d1.items():
            if keys=='email2':
                email_signin=values
            if keys=='psw':
                password_signin=values
        c1="insert into login_data values('{}','{}')".format(email_signin,password_signin)
        cursor.execute(c1)
        m1.commit()

        # def productpage(req):
        #     m=sql.connect(host='localhost',user='root',password='Jahanvi@123',database='superstore_data')
        #     cursor=m.cursor()
        if req.method == 'POST':
            class_name = req.POST.get('class_name')
            button_name = req.POST.get('buy')
            section_id = req.POST.get('section_id')
            if section_id=='furniture' and class_name == 'product' and button_name is not None:
                return render(req,'home.html')

                # else:
                #     return render(req,'home.html')


        return render(req,'productpage.html')
    return render(req,'loginpage.html')



def signup(req):
    global name,email_signup,password_signup
    if req.method=='POST':
        m=sql.connect(host='localhost',user='root',password='Jahanvi@123',database='superstore_data')
        cursor=m.cursor()
        name = req.POST['Name1']
        email_signup = req.POST['Email1']
        password_signup = req.POST['Password1']
        d=req.POST
        for key,value in d.items():
            if key=='Name1':
                name=value
            if key=='Email1':
                email_signup=value
            if key=='Password1':
                password_signup=value
        #         #def __enter__():
        #         #cursor = connection.cursor()
        cursor.execute("select * from signup_data where email=%s", [email_signup])
        if cursor.fetchall():
            messages.error(req, 'Email already exists.')
            return redirect('signup')
        else:
            c="insert into signup_data values('{}','{}','{}')".format(name,email_signup,password_signup)
            messages.success(req, 'Account created successfully.')
        cursor.execute(c)
        m.commit()
    return render(req,'loginpage.html')

def product_detail(request, id):
    product = get_object_or_404(Product, pk=id)
    return render(request, 'product_detail.html', {'product': product})

#def product(req):
#     #return render(req,'productpage.html')
# from django.http import JsonResponse
# import urllib.parse

# def generate_barcode(req):
#     barcode_data = '123456789012'
#     barcode_url = f"https://barcode.tec-it.com/barcode.ashx?data={urllib.parse.quote(barcode_data)}&code=Code128&dpi=96"
#     return JsonResponse({'barcode_url': barcode_url})

